import Job from "../../components/job";

export default function JobPage() {
    return (
        <Job />
    );
}