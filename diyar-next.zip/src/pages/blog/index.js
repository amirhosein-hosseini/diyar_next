import Blog from "../../components/blog/blog";

export default function BlogPage() {
    return (
        <Blog />
    );
}