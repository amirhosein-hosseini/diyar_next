import SingleBlog from "../../../components/blog/singleBlog";

export default function SingleBlogPage() {
    return (
        <SingleBlog />
    );
}