import ProgramSubCategory from "../../../components/program/programSubCategory";

export default function categoryPage() {
    return (
        <ProgramSubCategory />
    );
}
  