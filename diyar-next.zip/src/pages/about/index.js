import About from "../../components/about/index";


export default function AboutPage() {
    return (
        <About />
    );
}