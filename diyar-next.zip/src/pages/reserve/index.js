import Reserve from "../../components/Reserve";

export default function ReservePage() {
    return (
        <Reserve />
    );
  }
  