import SingleSample from "../../../components/sample/singleSample";

export default function SubCategoryPage() {
    return (
        <SingleSample />
    );
}