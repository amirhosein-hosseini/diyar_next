import Program from "../../../components/program";


export default function SubCategoryPage() {
    return (
        <Program />
    );
}