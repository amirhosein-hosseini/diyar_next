export const domain = "https://stage.hamidehsakak.com/";
export const prefix = "api/v1/"